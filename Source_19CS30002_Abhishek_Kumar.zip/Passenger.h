#ifndef PASSENGER_H
#define PASSENGER_H

#include <iostream> 
using namespace std;

class Passenger {};

#endif